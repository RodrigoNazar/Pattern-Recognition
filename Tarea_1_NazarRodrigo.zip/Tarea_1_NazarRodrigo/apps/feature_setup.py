
import cv2
from matplotlib import pyplot as plt
from matplotlib.image import imsave
import numpy as np
import argparse
import json
import os
import pandas as pd

from utils.utils import (getThresholdImgs, printImg)
import utils.huMoments as hu


def obtainFeatures(img_path):

    print(f'\nObteniendo características de las letras de {img_path}...')

    data = {
        'A': [],
        'S': [],
        'D': [],
        'F': [],
        'G': []
    }

    for letter in os.listdir(f'img/{img_path}'):
        for pic in os.listdir(f'img/{img_path}/{letter}'):
            img = cv2.imread(f'img/{img_path}/{letter}/{pic}')
            img = cv2.split(img)[0] # Obtenemos sólo un canal
            phi1, phi2, phi3, phi4, phi5, phi6, phi7 = hu.huMoments(img)

            new_data = {
                'file': f'img/{img_path}/{letter}/{pic}',
                'data': {
                    'phi1': phi1,
                    'phi2': phi2,
                    'phi3': phi3,
                    'phi4': phi4,
                    'phi5': phi5,
                    'phi6': phi6,
                    'phi7': phi7
                }
            }
            data[letter].append(new_data)

    with open(f'data/{img_path}_data.json', 'w') as json_file:
        json.dump(data, json_file, indent=2)


def MinMaxNormalization(file):

    with open(f'data/{file}_data.json', 'r') as json_file:
        json_data = json.load(json_file)

    huMoments = ('phi1', 'phi2', 'phi3', 'phi4', 'phi5', 'phi6', 'phi7')

    # Obtenemos los valores de cada uno de los momentos calculados
    moments_data = {mom: [] for mom in huMoments}

    for letter in json_data:
        for data in json_data[letter]:
            for huElem in data['data']:
                moments_data[huElem].append(data['data'][huElem])

    # Creamos un diccionario con los valores máximos y mínimos de cada momento
    normalizations = {}
    for moment in moments_data:
        min_val, max_val = min(moments_data[moment]), max(moments_data[moment])
        # print(moment, min_val, max_val)
        normalizations[moment] = {'min': min_val,
                                  'max': max_val}

    # Aplicamos las respectivas normalizaciones a cada uno de los momentos
    for letter in json_data:
        for data in json_data[letter]:
            for huElem in data['data']:
                min_val, max_val = normalizations[huElem]['min'], normalizations[huElem]['max']
                data['data'][huElem] = (data['data'][huElem] - min_val)/(max_val-min_val)

    with open(f'data/{file}_norm_data.json', 'w') as json_file:
        json.dump(json_data, json_file, indent=2)


def setupImgsFeatures(*pics):

    print('\n1) Revisando que estén todas las imágenes segmentadas...')
    options = ('A', 'S', 'D', 'F', 'G')
    segmentadas = True

    # Primero revisamos si tenemos todas las fotografías
    # de las letras individuales
    for pic in pics:
        dir = 'training' if 'Training' in pic else 'testing'
        pic_number = 18*2*2 if dir == 'training' else 18*2
        for option in options:
            if len(os.listdir('img/' + dir + '/' + option + '/')) != pic_number:
                segmentadas = False

    print('\n2) Revisando las características de cada imagen...')
    data_files = os.listdir('data/')

    pics = ['testing', 'training']

    # Se obtienen las características de las imágenes
    for pic in pics:
        data_path = pic + '_data.json'
        # Revisamos la información que ya está
        if data_path not in data_files:
            obtainFeatures(pic)
        else:
            print(f'\tLas imágenes de {pic} ya tienen sus características!')

    print('\n3) Normalizando los datos...')

    # Se obtienen las características de las imágenes
    for pic in pics:
        data_path = pic + '_norm_data.json'
        # Revisamos la información que ya está
        if data_path not in data_files:
            MinMaxNormalization(pic)
        else:
            print(f'\tLas imágenes de {pic} ya tienen sus características normalizadas!')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--tr1_path', type=str, default='img/Training_01.png',
                        help="Dirección de la imagen a procesar")
    parser.add_argument('--tr2_path', type=str, default='img/Training_02.png',
                        help="Dirección de la imagen a procesar")
    parser.add_argument('--test1_path', type=str, default='img/Testing.png',
                        help="Dirección de la imagen a procesar")
    cmd_args = parser.parse_args()
    train_setup(cmd_args.t01_path, cmd_args.t02_path, cmd_args.test1_path)
