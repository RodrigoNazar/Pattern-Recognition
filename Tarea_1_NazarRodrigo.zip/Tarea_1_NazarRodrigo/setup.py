from setuptools import setup

setup(
    name='Tarea 1 - Patrones',
    version='1.0',
    description='Código de la tarea número 1 del curso de Reconocimiento' +
                ' de Patrones',
    author='Rodrigo Nazar Meier',
    author_email='rnazar@uc.cl',
    packages=['apps', 'utils']
)
